AVRRIO THEME V4 PRO

WHAT CHANGED
- Richer homepage
- Better header with search styling
- Trust row
- More complete collection page
- Product page with buying panel and detail sections
- General Avrrio Coffee branding, not locked to one roast

IMPORTANT SETUP
1. Upload theme zip in Shopify
2. Ensure collection handle is: avrrio-coffee
3. Ensure current featured product handle is: avrrio-french-roast
4. Add your product to the Avrrio Coffee collection
5. Preview and publish
